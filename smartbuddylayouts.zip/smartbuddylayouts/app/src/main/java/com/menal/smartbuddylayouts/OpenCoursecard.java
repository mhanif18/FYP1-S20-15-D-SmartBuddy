package com.menal.smartbuddylayouts;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class OpenCoursecard extends AppCompatActivity {
SearchView searchView;
ListView myList;
ArrayList<String> list;
ArrayAdapter<String> adapter1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open_coursecard);
        searchView=findViewById(R.id.searchView);
        myList=findViewById(R.id.myList);
        list= new ArrayList<String>();
        list.add("Operating Systems");
        list.add("Computer Networks");
        list.add("Computer Architecture");
        list.add("Discrete Structures");
        list.add("Calculus-1");
        list.add("Automata");
        list.add("Software Engineering");
        list.add("Data Structures");
        list.add("COAl");
        list.add("Artificial Intelligence");
        list.add("PIT");
        list.add("SMD");
        list.add("HCI");
        list.add("Prob and Stats");
        list.add("Calculus-2");
        list.add("Linear Algebra");
   adapter1= new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,list);
   myList.setAdapter(adapter1);
  myList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
      @Override
      public void onItemClick(AdapterView<?> adapterView, View view, int i, long l)
      {

          Intent intent5= new Intent(view.getContext(),OpenBuddyByCourseName.class);
          startActivity(intent5);
      }
  });
   searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
       @Override
       public boolean onQueryTextSubmit(String query) {
           return false;
       }

       @Override
       public boolean onQueryTextChange(String newText) {
           adapter1.getFilter().filter(newText);

           return false;
       }
   });

    }
}
