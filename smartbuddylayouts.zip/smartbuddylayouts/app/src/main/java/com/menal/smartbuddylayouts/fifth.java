package com.menal.smartbuddylayouts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class fifth extends AppCompatActivity {
Button reg_login_btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fifth);
        reg_login_btn1=findViewById(R.id.reg_login_btn);
        reg_login_btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity10001();
            }
        });
    }
    public void openActivity10001()
    {
        Intent intent12 = new Intent(this, MainActivity.class);
        startActivity(intent12);
    }
}