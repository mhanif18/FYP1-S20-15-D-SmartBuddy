package com.menal.smartbuddylayouts;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class chooseEnvironment extends AppCompatActivity implements View.OnClickListener {
    private CardView virtual_environment;
    private CardView phy_enviroment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_environment);
        virtual_environment=findViewById(R.id.virtual_environment);
        phy_enviroment=findViewById(R.id.phy_environment);
        phy_enviroment.setOnClickListener(this);
        virtual_environment.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent i;
        switch (view.getId()) {
            case R.id.phy_environment:
                i=new Intent(this,PhyEnvironment.class); startActivity(i); break;
            case R.id.virtual_environment:
                i=new Intent(this, VirEnvironment.class); startActivity(i); break;
            default: break;

        }
    }
}
