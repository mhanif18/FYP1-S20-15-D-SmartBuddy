package com.menal.smartbuddylayouts;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class PhyEnvironment extends AppCompatActivity {
    Button selectDate;
    TextView date;
    Button btnnext;
   // Button btnnext;
    DatePickerDialog datePickerDialog1;
    int year1;
    int month1;
    int dayOfMonth1;
    Calendar calendar1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phy_environment);

        selectDate = findViewById(R.id.btnDate);
        date = findViewById(R.id.tvSelectedDate);
       /*
      btnnext=findViewById(R.id.btnnext);
        btnnext.setOnClickListener(new View.OnClickListener() {
          @Override
         public void onClick(View view) {
             Toast.makeText(new PhyEnvironment(), "You will be notified about time once your buddy accepts your reuqest", Toast.LENGTH_LONG).show();
        }
        });
     */
        btnnext = findViewById(R.id.btnnext);
        btnnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity300();
            }
        });


        selectDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calendar1 = Calendar.getInstance();
                year1 = calendar1.get(Calendar.YEAR);
                month1 = calendar1.get(Calendar.MONTH);
                dayOfMonth1 = calendar1.get(Calendar.DAY_OF_MONTH);
                datePickerDialog1 = new DatePickerDialog(PhyEnvironment.this,R.style.DialogTheme,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                                date.setText(day + "/" + (month + 1) + "/" + year);
                            }
                        }, year1, month1, dayOfMonth1);
                datePickerDialog1.show();
            }
        });
    }

    public void openActivity300()
    {
        Intent intent10 = new Intent(this, finalphy.class);
        startActivity(intent10);
    }
}

