package com.menal.smartbuddylayouts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class forth extends AppCompatActivity {
Button reg_login_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forth);
        reg_login_btn=findViewById(R.id.reg_login_btn);
        reg_login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity1();
            }
        });
    }
    public void openActivity1()
    {
        Intent intent12 = new Intent(this, MainActivity.class);
        startActivity(intent12);
    }
}
