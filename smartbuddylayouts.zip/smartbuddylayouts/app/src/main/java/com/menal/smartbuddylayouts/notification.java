package com.menal.smartbuddylayouts;

public class notification {

    private  String time;

    private String name;
    private int image;
    private String msg;



    public notification(String time, String name, int image, String msg) {
        this.time = time;
        this.name = name;
        this.image = image;
        this.msg = msg;
    }

    public String getTime() {
        return time;
    }

    public String getName() {
        return name;
    }

    public int getImage() {
        return image;
    }

    public String getMsg() {
        return msg;
    }
}
