package com.menal.smartbuddylayouts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class Third extends AppCompatActivity {
 private Button reg1_btn;
 private Spinner spinner1;
 private Spinner spinner2;
 //private Button reg1_btn;
   // String[] DegreeNames={"Select Degree","Computer Science","Artifical Intelligence","Software Engineering","Data Science","Cyber Security"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
      // addItemsonSpinner2();
        //addListenerOnButton();

        //spinner1.setPrompt("Select Degree");

        addListenerOnSpinnerItemSelection();
        spinner1=findViewById(R.id.spinner1);
        spinner2=findViewById(R.id.spinner2);
        reg1_btn = findViewById(R.id.reg1_btn);
        reg1_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

              //  Toast.makeText(Third.this,"\nSpinner1 :"
                  //      + String.valueOf(spinner1.getSelectedItem()) + "\nSpinner2 :" +
                      //  String.valueOf(spinner2.getSelectedItem()),Toast.LENGTH_SHORT).show();
                openActivity4();
            }
        });
    }
   /* public void addItemsonSpinner2()
    {
        spinner2=(Spinner)findViewById(R.id.spinner2);
        List<String> list= new ArrayList<String>();
        list.add("Data Structure");
        list.add("Calculus");
        list.add("Object Oriented Programming");
        list.add("Linear Algebra");
        list.add("Programming Fundamentals");
        list.add("Discrete Structures");
        ArrayAdapter<String> dataAdapter= new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item);
        spinner2.setAdapter(dataAdapter);


    } */
    public void addListenerOnSpinnerItemSelection()
    {
       spinner1=findViewById(R.id.spinner1);
        spinner2=findViewById(R.id.spinner2);
       //spinner1.setOnItemSelectedListener(new CustomOnItemSelectedListener());

    }


    public void openActivity4()
    {
        Intent intent3= new Intent(this,fifth.class);
        startActivity(intent3);
    }
    }


       /* Spinner spin = (Spinner) findViewById(R.id.simpleSpinner);
        spin.setOnItemSelectedListener(this);
        spin.setPrompt("Select your Degree");

//Creating the ArrayAdapter instance having the bank name list
        ArrayAdapter aa = new ArrayAdapter(this,android.R.layout.simple_spinner_item,DegreeNames);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
//Setting the ArrayAdapter data on the Spinner
        spin.setAdapter(aa);
    }


    //Performing action onItemSelected and onNothing selected
    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int position,long id) {
        Toast.makeText(getApplicationContext(), DegreeNames[position], Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
// TODO Auto-generated method stub

    } */


