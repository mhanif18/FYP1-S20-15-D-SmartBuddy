package com.menal.smartbuddylayouts;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class junior_after_login extends AppCompatActivity implements View.OnClickListener {
    private CardView Buddylist_card;
    private CardView chatwithbuddy;

    private CardView lone;
    private CardView call_buddy;
    private CardView my_profile;
    private CardView notification_card;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_junior_after_login);
        Buddylist_card=findViewById(R.id.Buddylist_card);
        chatwithbuddy=findViewById(R.id.chatwithbuddy);
        lone=findViewById(R.id.lone);
        call_buddy=findViewById(R.id.call_buddy);
        my_profile=findViewById(R.id.my_profile);
        notification_card=findViewById(R.id.notification_card);
        Buddylist_card.setOnClickListener(this);
        chatwithbuddy.setOnClickListener(this);
        lone.setOnClickListener(this);
        call_buddy.setOnClickListener(this);
        my_profile.setOnClickListener(this);
        notification_card.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent i;
        switch (view.getId()) {
            case R.id.Buddylist_card:
                i = new Intent(this,BuddyList.class); startActivity(i); break;
            case R.id.chatwithbuddy:
                i = new Intent(this,Inboz.class); startActivity(i); break;
            case R.id.call_buddy:
                i = new Intent(this,OpenCallbuddy.class); startActivity(i); break;
            case R.id.my_profile:
                i = new Intent(this,OpenMyprofilecard.class); startActivity(i); break;
            case R.id.notification_card:

                i = new Intent(this,OpenNotificationcard.class); startActivity(i); break;
            case R.id.lone:
                i = new Intent(this,OpenCoursecard.class); startActivity(i); break;

                default: break;

        }


    }
}
