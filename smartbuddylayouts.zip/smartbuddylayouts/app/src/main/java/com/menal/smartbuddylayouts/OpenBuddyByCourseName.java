package com.menal.smartbuddylayouts;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class OpenBuddyByCourseName extends AppCompatActivity {
RecyclerView recyclerViewCourse;
RecyclerAdapterCourseBuddy adapter1;
List<CoursesBuddy> coursesLists;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open_buddy_by_course_name);
        coursesLists= new ArrayList<>();

        recyclerViewCourse= findViewById(R.id.recyclerViewCourse);
        recyclerViewCourse.setHasFixedSize(true);
        recyclerViewCourse.setLayoutManager(new LinearLayoutManager(this));
        coursesLists.add(new CoursesBuddy("Arufa suleman",4.7,R.drawable.ef, "i150676","Semester:7"));
        coursesLists.add(new CoursesBuddy("Amna Aleem",4.4,R.drawable.y, "i170123","Semester:5"));
        coursesLists.add(new CoursesBuddy("Ali Nadeem",4.1,R.drawable.a, "i160158","Semester:8"));
        coursesLists.add(new CoursesBuddy("Sana Iram",4.0,R.drawable.z, "i180100","Semester:6"));
        coursesLists.add(new CoursesBuddy("Muhammad Arif",3.8,R.drawable.ic_face_black_24dp, "i190676","Semester:3"));
        coursesLists.add(new CoursesBuddy("Ayela ",3.7,R.drawable.x, "i160458","Semester:4"));
        coursesLists.add(new CoursesBuddy("Ayan ",3.2,R.drawable.a, "i150676","Semester:7"));
        coursesLists.add(new CoursesBuddy("Sundus Ali",2.6,R.drawable.ic_face_black_24dp, "i180126","Semester:5"));
        adapter1= new RecyclerAdapterCourseBuddy(this,coursesLists);
        recyclerViewCourse.setAdapter(adapter1);



    }
}
