package com.menal.smartbuddylayouts;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Openchatbuddycard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_openchatbuddycard);
    }
}
