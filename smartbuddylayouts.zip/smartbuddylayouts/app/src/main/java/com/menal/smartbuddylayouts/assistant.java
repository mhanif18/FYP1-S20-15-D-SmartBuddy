package com.menal.smartbuddylayouts;

import androidx.appcompat.app.AppCompatActivity;

import android.database.DataSetObserver;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.animation.Animation;
import android.widget.AbsListView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class assistant extends AppCompatActivity {
    private static final String TAG = "ChatActivity";
    private ChatArrayAdapter chatArrayAdapter;
    private ListView listView;
    private boolean rightSide = true;
    private int choice=-1;
    private TextView rTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assistant);
        listView = (ListView) findViewById(R.id.msgview);
        chatArrayAdapter = new ChatArrayAdapter(this, R.layout.right);
        listView.setAdapter(chatArrayAdapter);

        rTextView = (TextView) findViewById(R.id.msgr);
        rTextView.setText("hello");
        rTextView.setMovementMethod(LinkMovementMethod.getInstance());
        rightSide=false;
        listView.setTranscriptMode(AbsListView.TRANSCRIPT_MODE_ALWAYS_SCROLL);
        listView.setAdapter(chatArrayAdapter);

        //to scroll the list view to bottom on data change
        chatArrayAdapter.registerDataSetObserver(new DataSetObserver() {
            @Override
            public void onChanged() {
                super.onChanged();
                listView.setSelection(chatArrayAdapter.getCount() - 1);
            }
        });
        chatArrayAdapter.add(new ChatMessage(!rightSide, "hey, How are you?"));
    }
}
