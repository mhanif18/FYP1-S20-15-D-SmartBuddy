package com.menal.smartbuddylayouts;

import android.app.Notification;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import static com.menal.smartbuddylayouts.R.layout.rows_notificaion;

public class RecyclerAdapterNotification extends RecyclerView.Adapter<RecyclerAdapterNotification.NotificationViewHolder> {
 private Context mctx;
 private List<notification> notificationList;

    public RecyclerAdapterNotification(Context mctx, List<notification> notificationList) {
        this.mctx = mctx;
        this.notificationList = notificationList;
    }

    @NonNull
    @Override
    public NotificationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(mctx);
        View view=inflater.inflate(rows_notificaion, parent,false);
        NotificationViewHolder holder= new NotificationViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull NotificationViewHolder holder, int position) {
        notification notifications=notificationList.get(position);
        holder.textViewtitle.setText(notifications.getName());
        holder.textViewDesc.setText(notifications.getMsg());
        holder.textViewtime.setText(notifications.getTime());
        holder.imageView.setImageDrawable(mctx.getResources().getDrawable(notifications.getImage()));
    }

    @Override
    public int getItemCount() {
        return notificationList.size();
    }

    class NotificationViewHolder extends RecyclerView.ViewHolder
    {
        ImageView imageView;
        TextView textViewtitle;
        TextView textViewDesc;
        TextView textViewtime;


        public NotificationViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView=itemView.findViewById(R.id.imageView);
            textViewtitle=itemView.findViewById(R.id.textViewTitle);
            textViewDesc=itemView.findViewById(R.id.textViewShortDesc);
            textViewtime=itemView.findViewById(R.id.textViewTime);
        }
    }
}
