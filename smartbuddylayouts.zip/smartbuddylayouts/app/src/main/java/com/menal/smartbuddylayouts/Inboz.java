package com.menal.smartbuddylayouts;


import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class Inboz extends AppCompatActivity {

    RecyclerView recyclerView;
    List<Message> country_list = new ArrayList<>();
    inboxAdapter indapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inboz);
        /* <----------------DUMMY DATA ------------->*/
        country_list.add(new Message("Hassan", "I've mailed you the notes"));
        country_list.add(new Message("Fatiha", "Meet me in CS lobby"));

        indapter = new inboxAdapter(country_list,this);
        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.addItemDecoration(new DividerItemDecoration(this,  LinearLayoutManager.VERTICAL));


        LinearLayoutManager layoutManager = new   LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(indapter);


    }


}