package com.menal.smartbuddylayouts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class finalphy extends AppCompatActivity {
    Button btn_last;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finalphy);
       btn_last=findViewById(R.id.btn_last);
       btn_last.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               openActivity31();
           }
       });


    }
    public void openActivity31()
    {
        Intent intent1 = new Intent(this, RatingScreen.class);
        startActivity(intent1);
    }
}
