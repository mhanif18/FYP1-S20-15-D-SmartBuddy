package com.menal.smartbuddylayouts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class OpenMyprofilecard extends AppCompatActivity {
    ImageView Edit_Image1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open_myprofilecard);
        Edit_Image1=findViewById(R.id.Edit_Image1);
        Edit_Image1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity101();
            }
        });
    }
    public void openActivity101()
    {
        Intent intent101 = new Intent(this, EditJuniorProfile.class);
        startActivity(intent101);
    }


}
