package com.menal.smartbuddylayouts;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;


import android.os.Bundle;

public class BuddyList extends AppCompatActivity  {
    RecyclerAdapter recyclerAdapter;
    RecyclerView RecyclerView;

    List<String> BuddyList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buddy_list);
        BuddyList = new ArrayList<>();

        RecyclerView = findViewById(R.id.recyclerView);
        recyclerAdapter = new RecyclerAdapter(BuddyList,this);
     RecyclerView.setLayoutManager(new LinearLayoutManager(this));
        RecyclerView.setAdapter(recyclerAdapter);

       DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(this, DividerItemDecoration.VERTICAL);

       RecyclerView.addItemDecoration(dividerItemDecoration);


        BuddyList.add("Ali Nadeem");
        BuddyList.add("Sara Ayan");
        BuddyList.add("Hammad Hassan");
        BuddyList.add("Muhammad Hanif");
        BuddyList.add("Tayyab Ali");
        BuddyList.add("Hassan Shehzad");
        BuddyList.add("Sara Ali");
        BuddyList.add("Neha khan");
        BuddyList.add("Hassan Shehzad");
        BuddyList.add("Nawal");



    }
}
