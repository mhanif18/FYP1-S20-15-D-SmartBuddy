package com.menal.smartbuddylayouts;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Handler;
import android.app.Activity;



import android.os.Bundle;

public class splashscreen extends AppCompatActivity {


    private  static int time=5000;  //  initialize your time value in milliseconds
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splashscreen);


        splashScreenMethod();       // invoking our method
    }

    void splashScreenMethod(){
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // going to next activity
                Intent i=new Intent(splashscreen.this,MainActivity.class);
                startActivity(i);
                finish();
            }
        },time);

    }
}




