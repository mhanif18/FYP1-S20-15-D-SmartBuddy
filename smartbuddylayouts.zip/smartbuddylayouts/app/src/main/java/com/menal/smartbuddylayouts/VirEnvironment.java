package com.menal.smartbuddylayouts;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;

import java.util.Calendar;

public class VirEnvironment extends AppCompatActivity {

Button   btnnext101;
Button selectDate01;
    DatePickerDialog datePickerDialog;
    TextView date1;
    int year;
    int month;
    int dayOfMonth;
    Calendar calendar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vir_environment);
        btnnext101 = findViewById(R.id.btnnext101);
        btnnext101.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity30();
            }
        });
      selectDate01=findViewById(R.id.selectDate01);
        date1 = findViewById(R.id.tvSelectedDate01);



      selectDate01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calendar = Calendar.getInstance();
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
                datePickerDialog = new DatePickerDialog(VirEnvironment.this,R.style.DialogTheme,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                                date1.setText(day + "/" + (month + 1) + "/" + year);
                            }
                        }, year, month, dayOfMonth);
                datePickerDialog.show();
            }
        });
    }

    public void openActivity30()
    {
        Intent intent1 = new Intent(this, finalvir.class);
        startActivity(intent1);
    }
}