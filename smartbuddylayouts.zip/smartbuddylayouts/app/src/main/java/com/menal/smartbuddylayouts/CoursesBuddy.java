package com.menal.smartbuddylayouts;

public class CoursesBuddy {

    private  String name1;

    public String getName1() {
        return name1;
    }

    public double getRating() {
        return rating;
    }

    public int getImage1() {
        return image1;
    }

    public String getRollnum() {
        return rollnum;
    }

    public String getSemester() {
        return semester;
    }

    private double rating;
    private int image1;
    private String rollnum;
    private String semester;

    public CoursesBuddy(String name1, double rating, int image1, String rollnum, String semester) {
        this.name1 = name1;
        this.rating = rating;
        this.image1 = image1;
        this.rollnum = rollnum;
        this.semester = semester;
    }
}
