package com.menal.smartbuddylayouts;

import android.content.Context;
import android.provider.CalendarContract;
import android.telephony.mbms.MbmsErrors;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class CustomCalendarView extends LinearLayout {
    ImageButton NextButton,PreviousButton;
    TextView CurrentDate;
    GridView gridView;
    private static final int MAX_CALENDAR_DAYS=42;
    Calendar calendar= Calendar.getInstance(Locale.ENGLISH);
    Context context;
    List<Date> dates= new ArrayList<>();
    List<Events> eventsList= new ArrayList<>();
    SimpleDateFormat dateFormat= new SimpleDateFormat("MMMM,yyyy",Locale.ENGLISH);
    SimpleDateFormat monthFormat= new SimpleDateFormat("MMMM",Locale.ENGLISH);
    SimpleDateFormat yearFormat= new SimpleDateFormat("yyyy",Locale.ENGLISH);




    public CustomCalendarView(Context context) {
        super(context);
        this.context=context;
        IntializeLayout();
        PreviousButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                calendar.add(Calendar.MONTH,-1);
                SetupCalendar();

            }
        });
        NextButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                calendar.add(Calendar.MONTH,1);
                SetupCalendar();
            }
        });

    }

    public CustomCalendarView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

    }

    public CustomCalendarView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }
    private void IntializeLayout()
    {
        LayoutInflater inflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view=inflater.inflate(R.layout.calendar_layout,this);
        NextButton=view.findViewById(R.id.btnnext);
        PreviousButton=view.findViewById(R.id.previousBtn);
        CurrentDate=view.findViewById(R.id.current_Date);
        gridView=view.findViewById(R.id.gridview);


    }
    private void SetupCalendar()
    {
              String currentDate=dateFormat.format(calendar.getTime());
                CurrentDate.setText(currentDate);
    }
}
