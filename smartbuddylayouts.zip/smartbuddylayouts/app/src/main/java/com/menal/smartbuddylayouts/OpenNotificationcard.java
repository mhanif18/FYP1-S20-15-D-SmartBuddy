package com.menal.smartbuddylayouts;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class OpenNotificationcard extends AppCompatActivity {
    RecyclerView recyclerViewNoti;
    RecyclerAdapterNotification adapter;
    List<notification> notificationList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open_notificationcard);
        notificationList=new ArrayList<>();
        recyclerViewNoti= (RecyclerView)findViewById(R.id.recyclerViewNoti);
//        recyclerViewNoti.setHasFixedSize(true);
       recyclerViewNoti.setLayoutManager(new LinearLayoutManager(this));
        notificationList.add
                (new notification("9:45 am","Sara Khan",R.drawable.z,
                        "Gave you rating of 4.5"));
        notificationList.add
                (new notification("8:15 am","Rehan",R.drawable.a,
                        "Would be available in University at 5:30 pm"));
        notificationList.add
                (new notification("6:30 pm","Iram Fatima",R.drawable.y,
                        "Wants to attend a session online"));
        notificationList.add
                (new notification("4:08 pm","Neha Ali",R.drawable.x,
                        "Gave you rating of 2.5"));
        notificationList.add
                (new notification("Tuesday","Tayyab",R.drawable.ic_face_black_24dp,
                        "Send a message "));
        notificationList.add
                (new notification("Monday","Alia Shehzad",R.drawable.ef,
                        "Send you a pdf document"));
  adapter= new RecyclerAdapterNotification(this,notificationList);
  recyclerViewNoti.setAdapter(adapter);
    }
}
