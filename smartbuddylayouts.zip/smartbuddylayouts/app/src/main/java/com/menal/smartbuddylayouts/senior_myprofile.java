package com.menal.smartbuddylayouts;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;


public class senior_myprofile extends AppCompatActivity {
    ImageView Edit_Image;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_senior_myprofile);
       Edit_Image=findViewById(R.id.Edit_Image);
       Edit_Image.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
              openActivity10();
          }
        });
    }
    public void openActivity10()
    {
        Intent intent10 = new Intent(this, Edit_Senior_Profile.class);
        startActivity(intent10);
    }


}
