package com.menal.smartbuddylayouts;

import android.content.Context;
import android.content.Intent;
import android.icu.text.Transliterator;
import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecyclerAdapterCourseBuddy extends RecyclerView.Adapter<RecyclerAdapterCourseBuddy.courseViewholder> {
    private Context mctx1;
    private List<CoursesBuddy> coursesLists;

    public RecyclerAdapterCourseBuddy(Context mctx1, List<CoursesBuddy> coursesLists) {
        this.mctx1 = mctx1;
        this.coursesLists = coursesLists;
    }

    @NonNull
    @Override
    public courseViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater1=LayoutInflater.from(mctx1);
        View view1=inflater1.inflate(R.layout.row_coursebuddy,null);
        courseViewholder holder1= new courseViewholder( view1);
        return holder1;
    }

    @Override
    public void onBindViewHolder(@NonNull courseViewholder holder, int position) {

         CoursesBuddy coursebuddy= coursesLists.get(position);
         holder.textViewTitle01.setText(coursebuddy.getName1());
         holder.textViewrollnumber.setText(coursebuddy.getRollnum());
         holder.textViewsemester.setText(coursebuddy.getSemester());
         holder.textViewRating.setText(String.valueOf(coursebuddy.getRating()));
         holder.imageView01.setImageDrawable(mctx1.getResources().getDrawable(coursebuddy.getImage1()));




    }

    @Override
    public int getItemCount() {
        return coursesLists.size();
    }

    class courseViewholder extends RecyclerView.ViewHolder implements View.OnClickListener{
        ImageView imageView01;
        TextView textViewTitle01, textViewrollnumber, textViewsemester,textViewRating;


        public courseViewholder(@NonNull View itemView) {
            super(itemView);
            imageView01=itemView.findViewById(R.id.imageView01);
            textViewTitle01=itemView.findViewById(R.id.textViewTitle01);
            textViewrollnumber=itemView.findViewById(R.id.textViewrollnumber);
            textViewsemester=itemView.findViewById(R.id.textViewsemester);
            textViewRating=itemView.findViewById(R.id.textViewRating);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            Intent intent1111=new Intent(mctx1,Openmybuddy.class);
            //  intent.putExtra("buddyname", textView.get(position));


            mctx1.startActivity(intent1111);
        }
    }
}
