package com.menal.smartbuddylayouts;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.content.ContextCompat;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import static android.widget.Toast.makeText;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder>{
    private static final String TAG = "RecyclerAdapter";
    List<String> BuddyList;
    int count=0;
     private Context context;


    public RecyclerAdapter(List<String>BuddyList,Context context)

    {
        this.context=context;
        this.BuddyList=BuddyList;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       // Log.i(TAG, "onCreateViewHolder: " + count++);
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());

        View view = layoutInflater.inflate(R.layout.row_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.rowCountTextView.setText(String.valueOf(position));
      // holder.textView.setText(BuddyList.get(position))
        holder.textView.setText(BuddyList.get(position));

    }

    @Override
    public int getItemCount() {
        return BuddyList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView imageView;
        TextView textView, rowCountTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            textView = itemView.findViewById(R.id.textView);
            rowCountTextView = itemView.findViewById(R.id.rowCountTextView);
            itemView.setOnClickListener(this);
        }


        @Override
        public void onClick(View view) {
         int position=getAdapterPosition();
           makeText(context, "postion" + position, Toast.LENGTH_SHORT).show();
          //  Log.d(TAG, "onClick: clicked on:" + textView.get(position));


           Toast.makeText(context,"postion" + position,Toast.LENGTH_SHORT).show();
          Intent intent=new Intent(context,Openmybuddy.class);
        //  intent.putExtra("buddyname", textView.get(position));


          context.startActivity(intent);
        }
    }
}
