package com.menal.smartbuddylayouts;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class senior_after_login extends AppCompatActivity implements View.OnClickListener {
    private CardView my_profile ;
    private CardView  calendar_buddy;
    private CardView inbox ;
    private CardView  notifications_card;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_senior_after_login);
        my_profile=findViewById(R.id.my_profile);
        calendar_buddy=findViewById(R.id.calendar_buddy);
        inbox=findViewById(R.id.inbox);
        notifications_card=findViewById(R.id.notifications_card);
        my_profile.setOnClickListener(this);
        calendar_buddy.setOnClickListener(this);
        inbox.setOnClickListener(this);
        notifications_card.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        Intent i;
        switch (view.getId()) {

            case R.id.inbox:
                i = new Intent(this,Inboz.class); startActivity(i); break;
            case R.id.calendar_buddy:
                i = new Intent(this,senior_calendar.class); startActivity(i); break;
            case R.id.my_profile:
                i = new Intent(this,senior_myprofile.class); startActivity(i); break;
            case R.id.notifications_card:

                i = new Intent(this,OpenNotificationcard.class); startActivity(i); break;
            default: break;

        }
    }
}
