package com.menal.smartbuddylayouts;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Second extends AppCompatActivity {
    private Button reg_btn;
    private  Button reg_login_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        reg_login_btn=findViewById(R.id.reg_login_btn);

         reg_btn = findViewById(R.id.reg_btn);
         reg_btn.setOnClickListener(new View.OnClickListener() {
          @Override
         public void onClick(View view) {
             openActivity3();
          }
        });
         reg_login_btn.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 openActivity5();
             }
         });
        }
          public void openActivity3()
          {
            Intent intent111 = new Intent(this, forth.class);
          startActivity(intent111);
         }
    public void openActivity5()
    {
        Intent intent12 = new Intent(this, MainActivity.class);
        startActivity(intent12);
    }





}

