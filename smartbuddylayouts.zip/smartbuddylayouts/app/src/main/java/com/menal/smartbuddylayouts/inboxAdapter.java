package com.menal.smartbuddylayouts;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class inboxAdapter extends RecyclerView.Adapter<inboxAdapter.MyViewHolder> {

    List<Message> list_country;
    Context c;

    public inboxAdapter(List<Message> list_country, Context c) {
        this.list_country = list_country;
        this.c=c;
    }
    @NonNull
    @Override
    public inboxAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.message_row_layout, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull inboxAdapter.MyViewHolder holder, int position) {
        final Message country = list_country.get(position);
        holder.name.setText(country.getTitle());
        holder.phoneno.setText(country.getSubtitle());
        holder.clickrow.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(c,assistant.class);
                intent.putExtra("contactinfo",country.toString());
                c.startActivity(intent);
            }

        });

    }

    @Override
    public int getItemCount() {
        return list_country.size();
    }
    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView name,phoneno;
        CircleImageView contact_image;
        LinearLayout clickrow;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.title_textView);
            phoneno=itemView.findViewById(R.id.subtitle_textView);
            contact_image=itemView.findViewById(R.id.contactimage);
            clickrow=itemView.findViewById(R.id.clickrow);
        }
    }

    public class inboxHolder extends RecyclerView.ViewHolder {
        TextView title, subtitle;

        public inboxHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.title_textView);
            subtitle =itemView.findViewById(R.id.subtitle_textView);
        }
    }
}