package com.menal.smartbuddyfyp1;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class SeniorReg extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_senior_reg);
    }
}
