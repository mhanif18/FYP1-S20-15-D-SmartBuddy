package com.zeelawahab.i160021_i160099;

public class User {

    private String email;
    private String name;

    public User(String e,String n){
        email=e;
        name=n;
    }
}
